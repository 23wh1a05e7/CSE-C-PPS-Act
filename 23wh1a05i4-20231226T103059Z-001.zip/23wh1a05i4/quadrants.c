#include<stdio.h>
void quadrant(int,int);
void main()
{
int s,t;
printf("\nenter s,t values");
scanf("%d,%d",&s,&t);
quadrant(s,t);
}
void quadrant(int x_co_ordinate,int y_co_ordinate)
{
if(x_co_ordinate>0&&y_co_ordinate>0)
printf("\n ouadrant one:");
else if(x_co_ordinate<0&&y_co_ordinate<0)
printf("\n quadrant three:");
else if(x_co_ordinate<0&&y_co_ordinate>0)
printf("\n second quadrant:");
else{
printf("\n quadrant four:");
}
printf("good morning");
void quadrant(int,int)
{
int a,b;
printf("enter a,b values:");
scanf("%d,%d",&a,&b);
quadrant(a,b);
}
}
