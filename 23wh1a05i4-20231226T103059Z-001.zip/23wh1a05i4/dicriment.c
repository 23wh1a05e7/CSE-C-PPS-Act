#include<stdio.h>
void main()
{
int a,b,c,d,f;
printf("enter a value");
scanf("%d",&a);
b=a--;
c=--a;
d=b--;
f=--d;
printf("%d,%d,%d,%d,%d",a,b,c,d,f);
}
