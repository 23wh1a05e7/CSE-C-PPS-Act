#include<stdio.h>
void main()
{
int n=1,k,i,j;



for(i=1;i<=10;i++)

{

for(j=1;j<=5;j++)
{
 k=i*j;

}
}
printf("%5d",k);
}
