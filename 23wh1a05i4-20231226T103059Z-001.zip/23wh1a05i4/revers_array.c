#include<stdio.h>
void main()
{
int i,n;
int a[n];
printf("enter size of the array");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
printf("%2d",a[i]);
}
printf("\n reverse of array");
for(i=n-1;i>=0;i--)
{
printf("%2d",a[i]);
}
printf("\n");
}
