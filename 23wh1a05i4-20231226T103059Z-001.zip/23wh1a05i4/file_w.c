#include<stdio.h>
void main()
{
 char ch;
 FILE *fp;
 fp=fopen("a.txt","w");
 printf("enter characters:");
   while((ch=getchar())!=EOF)
    putc(ch,fp);
    fclose(fp);
}
