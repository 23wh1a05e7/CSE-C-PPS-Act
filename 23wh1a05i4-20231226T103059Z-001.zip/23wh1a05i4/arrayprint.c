#include<stdio.h>
void main()
{
int i,n;
int a[n];
printf("enter size of array");
scanf("%d",&n);
printf("enter elements of array");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
printf("\n elements of the array are:");
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("\n");
}
