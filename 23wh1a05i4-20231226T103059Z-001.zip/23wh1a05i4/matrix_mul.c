#include<stdio.h>
void main()
{
int a[10][10],b[10][10],c[10][10],i,j,k,m,n,p,q;
printf("enter r&c of m1");
scanf("%d,%d",&m,&n);
printf("enter r&c of m2");
scanf("%d,%d",&p,&q);
if(n!=p)
{
printf("multiplication is not possible");
}
else
{
printf("enter the elements of m1");
for(i=0;i<m;i++)
for(j=0;j<n;j++)
{
scanf("%d",&a[i][j]);
}
printf("enter the elements of m2");
for(i=0;i<p;i++)
for(j=0;j<q;j++)
{
scanf("%d",&b[i][j]);
}
printf("matrix multiplication is:");
for(i=0;i<m;i++)
for(j=0;j<q;j++)
{
c[i][j]=0;
for(k=0;k<n;k++)
{
c[i][j]=c[i][j]+a[i][j]*b[i][j];
printf(" ");
}
}
for(i=0;i<m;i++)
for(j=0;j<q;j++)
{
printf("%d",c[i][j]);
}
}
printf("\n");
}
