#include<stdio.h>
void main()
{
int n,i,j,k;
printf("enter n value:");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
for(j=i;j<=n-i;++j)
printf(" ");
for(k=1;k<=i;k++)
{
printf("%2d",k);
}
printf("\n");
}
}
