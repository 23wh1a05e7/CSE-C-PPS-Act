#include<stdio.h>
#include<string.h>
void main()
{
char str[50];
char fname[30];
FILE *fp;
printf("enter file name");
gets(fname);
fp=fopen("fname","w");
printf("enter the strings");
do
{
gets(str);
strcat(str,"\n");
fputs(str,fp);
}
while(*str !="\n");
fclose(fp);
}

