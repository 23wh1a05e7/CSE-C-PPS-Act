#include<stdio.h>
void main()
{
int i,j,r,space,coef;
printf("enter no of rows");
scanf("%d",&r);
for(i=0;i<r;i++)
{
for(space=1;space<=r-i;space++)
{
printf(" ");
for(j=0;j<=i;j++)
{
if(i==0||j==0)
  coef=1;
else
  coef=coef*(i-j+1);
  printf("%d",coef);
}
  printf("\n");
}
}
}

