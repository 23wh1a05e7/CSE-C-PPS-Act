#include<stdio.h>
long int fact(n);
void main()
{
int n;
printf("enter number");
scanf("%d",&n);
printf("%ld",fact(n));
}
long int fact(x)
{
int factorial;
if(x==0)
return 1;
else factorial=x*fact(x-1);
return factorial;
}
