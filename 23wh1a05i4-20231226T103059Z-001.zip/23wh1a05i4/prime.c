#include<stdio.h>
void prime(int);
void main()
{
int a;
printf("enter a number:");
scanf("%d",&a);
prime(a);
}
void prime(int a)
{
int i,count=0;
for(i=0;i<=a;i++)
{
if(a%i==0)
count++;
}
if(count==2)
printf("\n %d is a prime number",a);
else
printf("\n %d is not a prime number",a);
}


