#include<stdio.h>
void main()
{
int a[10][10],b[10][10],c[10][10],i,j,k,m,n,p,q;
printf("enter rows and columns of 1st matrix:");
scanf("%d,%d",&m,&n);
printf("enter rows and columns of 2nd matrix:");
scanf("%d,%d",&p,&q);
if(n!=p)
{
printf("multiplication is not possible");
}
else
{
printf("enter the elements of a");
for(i=0;i<m;i++)
{
for(j=0;j<n;j++)
{
scanf("%d",&a[i][j]);
}
}
printf("enter elements of 2nd array");
for(i=0;i<p;i++)
{
for(j=0;j<q;j++)
{
scanf("%d",&b[i][j]);
}
}
printf("matrix multiplication");
for(i=0;i<m;i++)
{
for(j=0;j<q;j++)
{
c[i][j]=0;
for(k=0;k<n;k++)
{
c[i][j]=c[i][j]+a[i][k]*b[k][i];
}
}
}
for(i=0;i<m;i++)
{
for(j=0;j<q;j++)
{
printf("%d",c[i][j]);
}
}
}
