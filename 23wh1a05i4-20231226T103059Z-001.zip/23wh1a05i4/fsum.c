#include<stdio.h>
int sum(int,int);
int main(void)
{
int total;
total=sum(5,6);
printf("the total=%d\n",total);
return 0;
}
int sum(int a,int b)
{
printf("enter a ,b vallues");
scanf("%d,%d",&a,&b);
int s;
s=a+b;
return s;
}
