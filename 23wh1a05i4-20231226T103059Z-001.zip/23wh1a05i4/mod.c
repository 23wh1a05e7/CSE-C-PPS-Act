#include<stdio.h>
void main()
{
int x,y,rem;
printf("enter x,y values");
scanf("%d"" %d",%x,%y);
rem=x%y;
printf("%d",rem);
}
