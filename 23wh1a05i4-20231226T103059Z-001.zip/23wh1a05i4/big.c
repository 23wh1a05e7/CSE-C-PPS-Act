#include<stdio.h>
void main()
{
int x,y,z;
printf("enter x,y,z values");
scanf("%d,%d,%d",&x,&y,&z);
(x>y && x>z)?printf("x is big"):printf("x is not big");
(y>x && y>z)?printf("y is big"):printf("y is not big");
(z>x && z>y)?printf("z is big"):printf("z is not big");
}
