#include<stdio.h>
#include<string.h>
void main()
{
char s[100];
int l=0;
printf("entr a string");
scanf("%s",s);
l=strlen(s);
printf("revers of the string\n");
for(s[l]='\0';l>=0;l--)
{
printf("%c",s[l]);
}
printf("\n");
}
