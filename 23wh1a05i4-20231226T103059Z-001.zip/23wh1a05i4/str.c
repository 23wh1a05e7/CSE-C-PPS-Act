#include<stdio.h>
#include<stdlib.h>
void main()
{
char s[50];
printf("enter a string:");
gets(s);
puts(s);
}
