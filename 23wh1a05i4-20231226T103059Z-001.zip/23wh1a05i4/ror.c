#include<stdio.h>
void main()
{
int a,b;
printf("enter a,b value");
scanf("%d,%d",&a,&b);
printf("%d",a<b);
}
