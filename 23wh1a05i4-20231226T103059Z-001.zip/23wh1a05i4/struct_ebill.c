#include<stdio.h>
struct ebill
{
	char name[30];
	int units;
	int mno;
	float price;
	int prev_reading;
	int pres_reading;
	float elecbill;
};
void main()
{
	struct ebill b1[10];
	int n,i;
        printf("enter no of persons:");
        scanf("%d",&n);
	for(i=0;i<n;i++)
        {
	 
	 printf("enter person name:\n");
	 scanf("%s",b1[i].name);
	 printf("enter meter number:\n");
	 scanf("%d",&b1[i].mno);
	 printf("enter present reading:\n");
	 scanf("%d",&b1[i].pres_reading);
	 printf("enter previous reading:\n");
	 scanf("%d",&b1[i].prev_reading);
	 printf("enter price:\n");
	 scanf("%f",&b1[i].price);
         }
	// b1[i].units=(b1[i].pres_reading)-(b1[i].prev_reading);
         //b1[i].elecbill=(b1[i].units)*(b1[i].price);
	 printf("the electricbill details are as follows:");
         for(i=0;i<n;i++)
         {
           b1[i].units=(b1[i].pres_reading)-(b1[i].prev_reading);
           b1[i].elecbill=(b1[i].units)*(b1[i].price);

	  printf("%s\n",b1[i].name);
	  printf("the meter no is %d \n",b1[i].mno);
	  printf("no of units is %d \n",b1[i].units);
	  printf("electricity bill is %f \n",b1[i].elecbill);
         } 
}
