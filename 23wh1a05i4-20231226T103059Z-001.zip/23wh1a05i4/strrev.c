#include<stdio.h>
#include<string.h>
void main()
{
char s[]="shreya",r;
r=strrev(s);
printf("%s",strrev(s));
}
