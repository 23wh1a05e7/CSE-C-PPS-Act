#include<stdio.h>
void main()
{
int a,b,c,d;
printf("enter a value");
scanf("%d",&a);
b=a++;
c=++a;
d=++c;
printf("%d",a);
printf("%d",b);
printf("%d",c);
printf("%d",d);
}

