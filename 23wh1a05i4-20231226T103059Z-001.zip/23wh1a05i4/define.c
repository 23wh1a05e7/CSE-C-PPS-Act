#include<stdio.h>
#define PI 3.14
void main()
{
int r;
printf("enter radius");
scanf("%d",&r);
float a;
a=PI*r*r;
printf("area of circle is %f",a);
}
