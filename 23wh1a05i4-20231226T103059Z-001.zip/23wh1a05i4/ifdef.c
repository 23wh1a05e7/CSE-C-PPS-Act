#include<stdio.h>
#define AGE 18
int main()
{
#ifdef AGE
printf("iam %d years old.\n",AGE);
#endif
printf("this is a sample program on #ifdef\n");
return 0;
}
