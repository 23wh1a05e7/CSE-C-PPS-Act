#include<stdio.h>
void main()
{
int n,i,a[10],b[10];
printf("enter size");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
   b[i]=a[i];
}
printf("elements stored in matrixb:");
for(i=0;i<n;i++)
{
printf("%2d",b[i]);
}
}
