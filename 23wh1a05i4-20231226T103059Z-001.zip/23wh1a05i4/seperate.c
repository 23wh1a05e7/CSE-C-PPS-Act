#include<stdio.h>
void main()
{
char s[50];
int l=0;
printf("enter a string");
gets(s);
puts(s);
printf("the characters of the stirnga are:\n");
while(s[l] != 0)
{
printf("%2c",s[l]);
l++;
}
printf("\n");
}
