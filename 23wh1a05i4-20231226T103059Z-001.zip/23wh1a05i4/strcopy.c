#include<stdio.h>
void main()
{
char s1[100],s2[100];
int i=0;
printf("enter a string:");
gets(s1);
while(s1[i] !='\0')
{
s2[i]=s1[i];
i++;
}
s1[i]='\0';
printf("%s",s2);
}
