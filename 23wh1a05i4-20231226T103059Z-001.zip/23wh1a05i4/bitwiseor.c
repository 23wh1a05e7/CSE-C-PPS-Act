#include<stdio.h>
void main()
{
int x,y;
printf("enter x,y value");
scanf("%d,%d",&x,&y);
printf("%d",x|y);
}
