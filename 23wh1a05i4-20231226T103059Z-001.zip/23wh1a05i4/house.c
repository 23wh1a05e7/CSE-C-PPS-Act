#include<stdio.h>
void main()
{
int n,price,no_of_br,sf;
float avg;
printf("entr no of houses");
scanf("%d",&n);
if(no_of_br=1||no_of_br=2)
{
av


