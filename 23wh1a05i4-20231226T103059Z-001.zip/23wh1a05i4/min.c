#include<stdio.h>
void main()
{
int i,n,min,a[10];
printf("enter size");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
min=a[0];
for(i=0;i<n;i++)
{
if(a[i]<min)
{
  min=a[i];
}
}
printf("minimum element is:%d",min);
}
