#include<stdio.h>
double sqr(double num)
{
return (num*num);
}
int main()
{
int num;
double n;
printf("enter any number:");
scanf("%d",&num);
n=sqr(num);
printf("the square of %d is:%2f\n",num,n);
return 0;
}
