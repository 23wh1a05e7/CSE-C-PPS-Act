#include<stdio.h>
void check_even(int);
void main()
{
int a,b;
printf("enter a,b :");
scanf("%d,%d",&a,&b);
check_even( a);
check_even( b);
}
void check_even(int num)
{
if(num%2==0)
{
printf("\n given number is even");
}
else
{
printf("given number is 0dd number");
}
}
