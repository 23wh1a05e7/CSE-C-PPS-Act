#include<stdio.h>
void main()
{
char c='@';
printf("%d",c);
}
