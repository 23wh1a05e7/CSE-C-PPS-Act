#include<stdio.h>
void main()
{
int i,n,a[10],sum=0;
printf("enter size of the array");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
sum=sum+a[i];
}
printf("%d",sum);
}
