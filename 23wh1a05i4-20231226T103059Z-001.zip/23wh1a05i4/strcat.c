#include<stdio.h>
#include<string.h>
int main()
{
char s1[50]="this is an";
char s2[50]="example";
strcat(s1,s2);
printf(" %s", s1);
return 0;
}
