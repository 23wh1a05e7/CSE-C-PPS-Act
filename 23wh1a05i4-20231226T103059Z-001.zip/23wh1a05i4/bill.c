#include<stdio.h>
void main()
{
int present_reading,previous_reading,no_of_units,mno;
float price,amount;
printf("enter mno");
scanf("%d",&mno);
printf("enter present_reading,previous_reading");
printf("enter price");
scanf("%f",&price);
no_of_units=present_reading-previous_reading;
amount=no_of_units*price;
printf("%f",amount);
}
