#include<stdio.h>
void main()
{
register int x;
for(x=0;x<=10;x++)
printf("%d",x);
}
