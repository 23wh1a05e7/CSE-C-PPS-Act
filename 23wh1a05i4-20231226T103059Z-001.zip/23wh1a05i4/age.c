#include<stdio.h>
void main()
{
int age;
printf("enter age");
scanf("%d",&age);
if(age>=18)
{
printf("you are major");
}
else
{
printf("you are minor");
}
}
