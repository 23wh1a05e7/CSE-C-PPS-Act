#include<stdio.h>
#include<string.h>
void main()
{
int l;
char s[50];
printf("enter a string:");
gets(s);
puts(s);
l=strlen(s);
printf("%d",l);
}
