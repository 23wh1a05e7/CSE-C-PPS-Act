#include<stdio.h>
void leap_year(int);
void main()
{
int year;
printf("enter a year:");
scanf("%d",&year);
leap_year(year);
}
void leap_year(int year)
{
if((year%400==0)||(year%4==0)&&(year%100==0))
{
printf("\n %d is leap year",year);
}
else
{
printf("\n %d is not a leap year",year);
}
}
