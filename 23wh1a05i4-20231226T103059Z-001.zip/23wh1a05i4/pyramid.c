#include<stdio.h>
void main()
{
int n,i,j,k;
printf("enter no of rows");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
for(j=1;2*(n-i);j++)
printf(" ");
for(k=1;k<2*i;k++)
printf("%d",i);
}
printf("\n");
}

