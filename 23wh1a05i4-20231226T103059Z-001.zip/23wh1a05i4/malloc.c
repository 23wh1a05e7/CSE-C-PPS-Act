#include<stdio.h>
#include<stdlib.h>
void main()
{
int *p;
p=(int *)malloc(sizeof(int);
printf("%d",p);
}
