#include<stdio.h>
void main()
{
int a=12,b=15,i,sum=0,rem=0;
for(i=a;i<=b;i++)
{

{
rem=a%10;
sum=sum+rem;
}
}
printf("%d",sum);

}
