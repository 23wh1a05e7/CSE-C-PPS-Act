#include<stdio.h>
#include<stdlib.h>
void main()
{
char s[50];
int l=0;
printf("enter a string:");
gets(s);
puts(s);
while(s[l] !='\0')
{
l++;
}
printf("length of the string is:%d\n",l-1);
}
