#include<stdio.h>
void main()
{
int n,i,num,min;
num=min;
printf("enter number of int");
scanf("%d",&n);
printf("enter numbers");


if(num<min)
printf("%d",num);

}
