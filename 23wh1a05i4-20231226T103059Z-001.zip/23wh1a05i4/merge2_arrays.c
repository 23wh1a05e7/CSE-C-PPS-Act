#include<stdio.h>
void main()
{
int i,j,k,s1,s2,s3,a[10],b[10],c[20];
printf("enter size of 1st array:");
scanf("%d",&s1);
printf("enter size of 2nd array");
scanf("%d",&s2);
printf("enter elements of 1st array:");
for(i=0;i<s1;i++)
{
scanf("%d",&a[i]);
printf("enter elements of 2nd array:");
for(i=0;i<s2;i++)
{
scanf("%d",&b[i]);
s3=s1+s2;
for(i=0;i<s1;i++)
{
c[i]=a[j];
i++;
}
for(j=0;j<s2;j++)
{
c[i]=b[j];
i++;
}
 for(i=0;i<s3;i++)
 {
 for(k=0;k<s3;k++)
 {
  if(c[k]<=c[k+1])
   {
    j=c[k+1];
    c[k+1]=c[k];
     c[k]=j;
    }
  }
  }
 for(i=0;i<s3;i++)
 {
 printf("%d",c[i]);
 }
 printf("\n");
}
