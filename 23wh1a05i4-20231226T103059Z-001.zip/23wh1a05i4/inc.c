


#include<stdio.h>
void main()
{
int i,a:
prinrtf("enter i value");
scanf("%d",i);
a=i++;
printf("%d",i);
}
