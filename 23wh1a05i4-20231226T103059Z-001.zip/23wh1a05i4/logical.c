#include<stdio.h>
void main()
{
int a,b,c;
printf("enter a,b values");
scanf("%d,%d",&a,&b);
c=a&&b;
printf("%d",c);
}
