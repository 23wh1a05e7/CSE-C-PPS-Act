#include<stdio.h>
void main()
{
int x,y;
printf("enter x,y values");
scanf("%d,%d",&x,&y);
printf("%d",x&y);
}
