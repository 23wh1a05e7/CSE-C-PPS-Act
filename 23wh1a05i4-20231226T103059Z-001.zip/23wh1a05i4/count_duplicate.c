#include<stdio.h>
void main()
{
int i,j,n,a[10];
int ctr=0;
printf("enter size");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
for(j=i+1;j<n;j++)
{
if(a[i]==a[j])
{
ctr++;
break;
}
}
}
printf("no of duplicate elements:%d\n",ctr);
}


