#include<stdio.h>
void main()
{
int a;
printf("enter a value");
scanf("%d",&a);
printf("%d",a>>2);
}
