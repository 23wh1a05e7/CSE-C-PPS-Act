#include<stdio.h>
void main()
{
struct book 
{
int pages;
float price;
char author[30];
};
struct book b1;
printf("enter no of pages:");
scanf("%d",&b1.pages);
printf("enter price:");
scanf("%f",&b1.price);
printf("enter author name:");
scanf("%s",b1.author);
printf("%d\n",b1.pages);
printf("%f\n",b1.price);
printf("%s\n",b1.author);
}
