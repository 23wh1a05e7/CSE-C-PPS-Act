#include<stdio.h>
void main()
{
int n,i,j,space,coef;
printf("enter no of rows");
scanf("%d",&n);
for(i=0;i<n;i++)
{
for(space=1;space<=n-1;space++)

printf(" ");
for(j=0;j<=i;j++)
{
if(i==0||j==0)
coef=1;
else
coef=coef*(i-j+1)/j;
printf("%d",coef);
}
printf("\n");
}
}
