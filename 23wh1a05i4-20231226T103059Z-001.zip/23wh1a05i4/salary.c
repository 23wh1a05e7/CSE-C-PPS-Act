#include<stdio.h>
void main()
{
int salary;
float ta,da,hra,gs;
printf("enter salary");
scanf("%d",&salary);
ta=salary*10/100;
da=salary*20/100;
hra=salary*30/100;
gs=ta+da+hra+salary;
printf("%f\n",ta);
printf("%f\n",da);
printf("%f\n",hra);
printf("%f\n",gs);
}
