#include<stdio.h>
void main()
{
char ch;
FILE *fp;
fp=fopen("a.txt","r");
printf("file contents are:");
 while((ch=getc(fp))!=EOF)
  putchar(ch);
 fclose(fp);
}
