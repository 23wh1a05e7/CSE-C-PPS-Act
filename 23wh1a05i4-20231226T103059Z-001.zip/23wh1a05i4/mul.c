#include<stdio.h>
void main()
{
int a;
float b,mul;
printf("enter a,b values");
scanf("%d%f",&a,&b);
mul=a*b;
printf("%f",mul);
}
