#include<stdio.h>
#include<string.c>
void main()
{
char s[50]="shreya";

printf("%s",strupr(s));
}
