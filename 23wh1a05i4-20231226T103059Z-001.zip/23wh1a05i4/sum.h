#include<stdio.h>
void main()
{
int a,b,sum=0,rem=0,i;
printf("enter a,b value");
scanf("%d,%d",&a,&b);
for(i=a;i<=b;i++)
{
 rem=a%10;
 sum=sum+rem;
 a=a/10;
}
printf("%d",sum);
}


