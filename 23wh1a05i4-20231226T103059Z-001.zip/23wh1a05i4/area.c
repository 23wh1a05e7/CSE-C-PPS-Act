#include<stdio.h>
void main()

{
int a,area;
printf("enter a value");
scanf("%d",&a);
area=a*a;
printf("area of sqare=%d",area);
}
