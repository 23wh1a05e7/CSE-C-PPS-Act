#include<stdio.h>
void main()
{
int c;
float f;
printf("enter temp in c");
scanf("%d",&c);
f=(9/5)*(c+32);
printf("%f",f);
}
