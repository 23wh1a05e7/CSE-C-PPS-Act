#include<stdio.h>
void main()
{
int n,i,j,k;
printf("enter no of rows");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
for(j=1;j<=n-i;j++)
printf(" ");
for(k=1;k<=1;k++)
printf("%2d",j);
}
printf("\n");
}
