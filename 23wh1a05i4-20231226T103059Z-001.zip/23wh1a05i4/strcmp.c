#include<stdio.h>
#include<string.h>
void main()
{
int r1,r2,r3;
char s1[]="shreya";
char s2[]="goud";
char s3[]="shreya";
r1=strcmp(s1,s2);
r2=strcmp(s2,s3);
r3=strcmp(s3,s2);
printf("%d\n",r1);
printf("%d\n",r2);
printf("%d\n",r3);
}
