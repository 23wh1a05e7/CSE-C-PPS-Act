#include<stdio.h>
#include<string.h>
void main()
{
char s[]="shreya";
char s1[20];
strcpy(s,s1);
printf("%s\n",s);
printf("%s",s1);
}

