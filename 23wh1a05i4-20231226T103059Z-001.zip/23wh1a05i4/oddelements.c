#include<stdio.h>
void main()
{
int i,j=0,k=0,n,a[10],b[10],c[10];
printf("enter size");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
if(a[i]%2==0)
{
b[j]=a[i];
j++;
}
else
{
c[k]=a[i];
k++;
}
}
for(i=0;i<j;i++)
{
printf("%3d",b[i]);
}
printf("\n the odd elements are");
for(i=0;i<k;i++)
{
printf("%d",c[i]);
}
printf("\n");
}
