#include<stdio.h>
#include<string.h>
void main()
{
char s[50];
printf("enter a string:");
  scanf("%s",s);
  printf("%s",s);
}
