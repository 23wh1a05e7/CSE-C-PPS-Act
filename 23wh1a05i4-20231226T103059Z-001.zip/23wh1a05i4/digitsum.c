#include<stdio.h>
void main()
{
 int a=12,b=15,i,sum=0,rem=0;
  i=a;
  for(i=a;i<=b;i++)
  {
    while(a!=0&&b!=0)
   {
     rem=a%10;
     sum=sum+rem;
     
     i++;
   }
  }
 printf("%d",sum);
}
