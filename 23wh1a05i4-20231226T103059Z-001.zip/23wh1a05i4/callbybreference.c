#include<stdio.h>
void swap(int *x,int *y);
void main()
{
int a=10,b=5;
printf("%d,%d\n",a,b);
swap(a,b);
printf("%d,%d",a,b);
}
void swap(int *x,int *y)
{
int t;
t=*x;
*x=*y;
*y=t;
}
