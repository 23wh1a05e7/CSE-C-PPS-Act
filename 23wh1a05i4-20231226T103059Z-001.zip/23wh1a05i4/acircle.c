#include<stdio.h>

void main()
{
int r;
float area,pi=3.14;
printf("enter r value");
scanf("%d",&r);
area=pi*r*r;
printf("area of circle=%f",area);
}
