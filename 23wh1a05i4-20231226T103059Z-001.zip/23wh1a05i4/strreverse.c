#include<stdio.h>
void main()
{
char s1[100],s2[100];
int i=0,j=0;
printf("enter a string:");
gets(s1);
while(s1[i] !='\0')
i++;
while(--i>=0)
{
s2[j]=s1[i];
j++;
}
s1[j]='\0';
printf("%s",s2);
}
