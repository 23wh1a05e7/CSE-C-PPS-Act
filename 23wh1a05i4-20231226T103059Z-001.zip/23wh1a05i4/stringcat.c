#include<stdio.h>
#include<string.h>
void main()
{
char s1[100],s2[50];
int i=0,j=0;
printf("enter first string:");
gets(s1);
printf("enter second string:");
gets(s2);
while(s1[i]!='\0')
{
s2[i]=s1[i];
i++;
}
while(s2[j]!='\0')
{

s2[i]=s1[j];
i++;
j++;
}
s2[j]='\0';

printf("%s",s2);
}


