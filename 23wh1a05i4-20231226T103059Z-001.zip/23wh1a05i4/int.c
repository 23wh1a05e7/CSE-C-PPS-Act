#include<stdio.h>
void main()
{
int n,i,num,min;
printf("enter no of integers");
scanf("%d",&n);
printf("enter integers");
scanf("%d",&num);

  
num=min;
 if(num<min)
printf("%d",num);

}
