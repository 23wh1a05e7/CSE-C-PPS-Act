#include<stdio.h>
#include<stdlib.h>
void main()
{
char s[100];
int l=0;
printf("enter a string:");
scanf("%s",s);

while(s[l]!='\0')
{
printf("%c",s[l]);
l++;
}
printf("\n");
}
