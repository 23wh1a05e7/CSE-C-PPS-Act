#include<stdio.h>
#include<string.h>
void main()
{
char str[]="shreya";
char r,ch='e';
r=strchr(str,ch);
if(r != '\0')
printf("thecharacter '%c' is found in string:");
else
printf("not found");
}

