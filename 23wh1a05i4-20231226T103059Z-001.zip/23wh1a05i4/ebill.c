#include<stdio.h>
void ebill(float);
void main()
{
int nou,p_r,prev_r,mno;
float price,amount;
printf("enter mno:");
scanf("%d",&mno);
printf("enter p_r&prev_r:");
scanf("%d,%d",&p_r,&prev_r);
printf("enter price:");
scanf("%f",&price);
nou=p_r-prev_r;
amount=nou*price;
printf("amount=%f",amount);
}

