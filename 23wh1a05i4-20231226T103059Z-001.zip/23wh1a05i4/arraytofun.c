#include<stdio.h>
void read(int a[],int n);
void main()
{
int n;
int a[10];
printf("\nenter size of the array:");
scanf("%d",&n);
printf("\nread the elements:");
read(a,n);
printf("\ndisplay the elements:");
display(a,n);
}
void read(int x[],int y)
{
int n,i;
for(i=0;i<n;i++)
{
printf("enter elements:");
scanf("%d",&x[i]);
}
}
void display(int x[],int n)
{
int i;
for(i=0;i<n;i++)
{
printf("%d",x[i]);
}
}
