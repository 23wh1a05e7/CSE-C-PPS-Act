#include<stdio.h>
void main()
{
int n,i,j,k,ctr=0,a[10];
printf("enter size of the array:\n");
scanf("%d",&n);
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
  ctr=0;
for(j=0,k=n;j<k+1;j++)
{
  if(i != j)
  {
    if(a[i]==a[j])
     {
      ctr++;
     }
   }
}
    if(ctr==0)
     {
     printf("%d",a[i]);
     }
}
  printf("\n");
}
