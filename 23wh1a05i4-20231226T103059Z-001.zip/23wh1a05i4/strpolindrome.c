#include<stdio.h>
#include<string.h>
void main()
{
char s[50];
char r;
printf("enter a string");
scanf("%s",s);
r=strrev(s);
if(s[50]==r)
{
printf("string is polindrome");
}
else{
printf("not a polindrome");
}
}
