#include<stdio.h>
void main()
{
int i,j,r,c,trace=0;

printf("enter rows and columns");
scanf("%d,%d",&r,&c);
int tra_a[r][c];
printf("enter elements");
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
{
scanf("%d",&tra_a[i][j]);
}
}
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
{
if(i==j)
{
trace=trace+tra_a[i][j];
}
}
}
printf("the trace of the matrix=%d\n",trace);
}
