#include<stdio.h>
void main()
{
int quantity,price;
float discount,original,total;
printf("enter quantity");

printf("enter price");
scanf("%d,%d",&quantity,&price);
total=quantity*price;
discount=total*0.2;
original=total-discount;
printf("%f\n",total);
printf("%f\n",discount);
printf("%f",original);
}
